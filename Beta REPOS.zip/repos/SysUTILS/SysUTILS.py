import psutil
import subprocess
import platform
import tkinter as tk
from tkinter import scrolledtext, filedialog

def clear_output():
    output_text.delete(1.0, tk.END)

def list_connected_devices():
    clear_output()
    output_text.insert(tk.END, "🔌 Connected Devices:\n\n")
    for partition in psutil.disk_partitions():
        output_text.insert(tk.END, f"Device: {partition.device}\n")
        output_text.insert(tk.END, f"  Mountpoint: {partition.mountpoint}\n")
        output_text.insert(tk.END, f"  File system type: {partition.fstype}\n\n")

def get_bios_info():
    clear_output()
    output_text.insert(tk.END, "🧬 BIOS Firmware Info:\n\n")
    try:
        if platform.system() == "Linux":
            output = subprocess.check_output("sudo dmidecode -t bios", shell=True, text=True)
        elif platform.system() == "Windows":
            output = subprocess.check_output("wmic bios get smbiosbiosversion", shell=True, text=True)
        else:
            output = "Unsupported OS for BIOS check."
        output_text.insert(tk.END, output)
    except Exception as e:
        output_text.insert(tk.END, f"Error fetching BIOS info:\n{e}\n")

def show_cpu_info():
    clear_output()
    output_text.insert(tk.END, "🖥️ CPU Info:\n\n")
    output_text.insert(tk.END, f"Logical CPUs: {psutil.cpu_count(logical=True)}\n")
    output_text.insert(tk.END, f"Physical Cores: {psutil.cpu_count(logical=False)}\n")
    output_text.insert(tk.END, f"CPU Usage: {psutil.cpu_percent(interval=1)}%\n")

def show_memory_info():
    clear_output()
    mem = psutil.virtual_memory()
    output_text.insert(tk.END, "💾 Memory Info:\n\n")
    output_text.insert(tk.END, f"Total: {mem.total / (1024**3):.2f} GB\n")
    output_text.insert(tk.END, f"Used: {mem.used / (1024**3):.2f} GB\n")
    output_text.insert(tk.END, f"Available: {mem.available / (1024**3):.2f} GB\n")
    output_text.insert(tk.END, f"Usage: {mem.percent}%\n")

def show_network_info():
    clear_output()
    net = psutil.net_if_addrs()
    output_text.insert(tk.END, "🌐 Network Info:\n\n")
    for interface, addrs in net.items():
        output_text.insert(tk.END, f"Interface: {interface}\n")
        for addr in addrs:
            output_text.insert(tk.END, f"  Address: {addr.address} ({addr.family.name})\n")
        output_text.insert(tk.END, "\n")

def show_battery_info():
    clear_output()
    battery = psutil.sensors_battery()
    if battery:
        output_text.insert(tk.END, "🔋 Battery Info:\n\n")
        output_text.insert(tk.END, f"Percentage: {battery.percent}%\n")
        output_text.insert(tk.END, f"Plugged In: {'Yes' if battery.power_plugged else 'No'}\n")
        output_text.insert(tk.END, f"Time Left: {battery.secsleft // 60} min\n")
    else:
        output_text.insert(tk.END, "Battery info not available on this system.\n")

def select_directory():
    folder = filedialog.askdirectory()
    if folder:
        output_text.insert(tk.END, f"📁 Selected directory:\n{folder}\n")

# GUI setup
window = tk.Tk()
window.title("🛠️ Enhanced System Utility Tool")

# Buttons
btns = [
    ("🔌 Show Connected Devices", list_connected_devices),
    ("🧬 Show BIOS Info", get_bios_info),
    ("🖥️ Show CPU Info", show_cpu_info),
    ("💾 Show Memory Info", show_memory_info),
    ("🌐 Show Network Info", show_network_info),
    ("🔋 Show Battery Info", show_battery_info),
    ("📁 Select Directory", select_directory),
]

for label, cmd in btns:
    tk.Button(window, text=label, command=cmd, width=40).pack(pady=4)

# Output box
output_text = scrolledtext.ScrolledText(window, width=90, height=25)
output_text.pack(pady=10)

# Run GUI
window.mainloop()
