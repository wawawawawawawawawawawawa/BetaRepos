say "If you see this 1 time, then the ZSH script works"
repeat 3x:
    say "If you see this 3 times, then the ZSH script works"
    