def run_zsharp(code):
    lines = code.strip().splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line.startswith("say "):
            print(line[4:].strip().strip('"'))
        elif line.startswith("repeat "):
            try:
                count_part = line.split()[1]  # e.g., '3x:'
                count = int(count_part.replace('x:', ''))  # Removes 'x:' and converts to int
            except ValueError:
                print(f"Error parsing repeat count in line: {line}")
                return
            i += 1
            if i < len(lines):
                block = lines[i].strip()
                if block.startswith("say "):
                    for _ in range(count):
                        print(block[4:].strip().strip('"'))
        i += 1
